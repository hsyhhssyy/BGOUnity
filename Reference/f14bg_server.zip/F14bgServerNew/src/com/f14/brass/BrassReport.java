package com.f14.brass;

import com.f14.bg.report.BgReport;

public class BrassReport extends BgReport {

	public BrassReport(Brass bg) {
		super(bg);
	}

}
