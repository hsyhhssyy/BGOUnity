package com.f14.brass.consts;

public enum BrassConnectType {
	CANAL, RAIL, VIRTUAL,
}
