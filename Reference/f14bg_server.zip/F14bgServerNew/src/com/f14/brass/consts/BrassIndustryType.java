package com.f14.brass.consts;

public enum BrassIndustryType {
	COTTEN_MILL, PORT, COAL_MINE, IRON_WORK, SHIPYARD
}
