package com.f14.brass.consts;

public enum BrassPeriod {
	CANAL_PERIOD, RAIL_PERIOD,
}
