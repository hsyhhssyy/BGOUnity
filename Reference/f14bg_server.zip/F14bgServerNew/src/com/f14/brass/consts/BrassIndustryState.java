package com.f14.brass.consts;

public enum BrassIndustryState {
	FACE_UP, FACE_DOWN,
}
