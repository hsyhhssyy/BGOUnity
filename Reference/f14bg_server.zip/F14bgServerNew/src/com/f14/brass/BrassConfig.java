package com.f14.brass;

import com.f14.bg.BoardGameConfig;

public class BrassConfig extends BoardGameConfig {

}
