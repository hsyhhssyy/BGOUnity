package com.f14.brass;

import com.f14.bg.player.Player;

public class BrassPlayer extends Player {

}
