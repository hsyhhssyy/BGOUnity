package com.f14.bg.listener;

import com.f14.bg.common.ParamSet;

/**
 * 中断监听器的参数
 * 
 * @author F14eagle
 *
 */
public class InterruptParam extends ParamSet {

}
