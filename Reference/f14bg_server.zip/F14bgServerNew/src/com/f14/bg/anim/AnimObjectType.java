package com.f14.bg.anim;

public enum AnimObjectType {
	CARD, CARD_BACK, TITLE,
}
