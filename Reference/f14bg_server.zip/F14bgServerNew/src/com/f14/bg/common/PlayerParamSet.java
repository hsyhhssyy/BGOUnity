package com.f14.bg.common;

/**
 * 玩家的参数集
 * 
 * @author F14eagle
 *
 */
public class PlayerParamSet extends ParamSet {
	public boolean responsed = false;
	public boolean needResponse = false;
}
