/**
 * 
 */
package com.f14.loveletter;

import com.f14.bg.BoardGame;
import com.f14.bg.report.BgCacheReport;

/**
 * @author 奈奈
 *
 */
public class LLReport extends BgCacheReport {

	public LLReport(BoardGame<?, ?> bg) {
		super(bg);
		// TODO Auto-generated constructor stub
	}

}
