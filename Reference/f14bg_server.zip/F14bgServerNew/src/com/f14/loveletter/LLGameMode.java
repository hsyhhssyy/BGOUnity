/**
 * 
 */
package com.f14.loveletter;

import java.util.Random;

import com.f14.bg.GameMode;
import com.f14.bg.exception.BoardGameException;

/**
 * @author 奈奈
 *
 */
public class LLGameMode extends GameMode {
	protected LoveLetter game;
	protected LLCardDeck deck;
	protected LLCardDeck removeDeck;
	public LLPlayer rsp;

	public LLGameMode(LoveLetter game) {
		this.game = game;
		this.init();
	}

	@SuppressWarnings("unchecked")
	@Override
	public LoveLetter getGame() {
		return this.game;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.f14.bg.GameMode#setupGame()
	 */
	@Override
	protected void setupGame() throws BoardGameException {
		LLConfig config = this.getGame().getConfig();
		LLResourceManager rm = this.game.getResourceManager();
		for (LLPlayer p : this.game.getValidPlayers()) {
			p = new LLPlayer();
			p.score = 0;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.f14.bg.GameMode#round()
	 */
	@Override
	protected void round() throws BoardGameException {
		waitForRoundPhase();
		waitForResultPhase();
	}

	@Override
	protected void initRound() {
		LLResourceManager rm = this.getGame().getResourceManager();
		Random r = new Random();
		this.rsp = this.getGame().getPlayer(r.nextInt(this.getGame().getCurrentPlayerNumber()));
		this.deck = new LLCardDeck();
		this.deck.addCards(rm.getAllCards());
		this.deck.shuffle();
		this.removeDeck = new LLCardDeck();
		for (int i = 0; i < this.getRemoveCardNum(); ++i) {
			LLCard c = this.deck.draw();
			this.removeDeck.addCard(c);
		}
		for (LLPlayer p : this.game.getValidPlayers()) {
			p.passed = false;
			p.protect = false;
			p.hand = new LLCardDeck();
			this.getGame().playerDrawCard(p);
		}
	}

	private void waitForRoundPhase() throws BoardGameException {
		LLRoundListener l = new LLRoundListener(this.rsp);
		this.addListener(l);
	}

	private void waitForResultPhase() throws BoardGameException {
		LLResultListener l = new LLResultListener(this);
		this.addListener(l);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.f14.bg.GameMode#isGameOver()
	 */
	@Override
	protected boolean isGameOver() {
		for (LLPlayer p : this.game.getValidPlayers()) {
			if (p.score >= this.getFinishScore()) {
				return true;
			}
		}
		return false;
	}

	@Override
	protected void endGame() throws BoardGameException {
		super.endGame();
		// 结束时算分
		LLEndPhase endPhase = new LLEndPhase();
		endPhase.execute(this);
	}

	private int getFinishScore() {
		int playernum = this.getGame().getCurrentPlayerNumber();
		switch (playernum) {
		case 2:
			return 7;
		case 3:
			return 5;
		case 4:
			return 4;
		default:
			return 0;
		}
	}

	private int getRemoveCardNum() {
		int playernum = this.getGame().getCurrentPlayerNumber();
		switch (playernum) {
		case 2:
			return 3;
		case 3:
		case 4:
			return 1;
		default:
			return 0;
		}
	}

	public int getAlivePlayerNum() {
		int res = 0;
		for (LLPlayer p : this.game.getValidPlayers()) {
			if (!p.passed)
				res++;
		}
		return res;
	}

}
