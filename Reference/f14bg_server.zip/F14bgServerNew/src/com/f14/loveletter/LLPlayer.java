/**
 * 
 */
package com.f14.loveletter;

import com.f14.bg.player.Player;

/**
 * @author 奈奈
 *
 */
public class LLPlayer extends Player {
	public int score;
	public boolean passed;
	public boolean protect;
	public LLCardDeck hand = new LLCardDeck();
}
