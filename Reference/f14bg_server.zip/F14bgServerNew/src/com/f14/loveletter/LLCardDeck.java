/**
 * 
 */
package com.f14.loveletter;

import com.f14.bg.component.CardDeck;

/**
 * @author 奈奈
 *
 */
public class LLCardDeck extends CardDeck<LLCard> {

}
