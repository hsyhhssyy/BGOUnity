/**
 * 
 */
package com.f14.loveletter;

/**
 * @author 奈奈
 *
 */
public class LLGameCmd {

	public static final int GAME_CODE_BASE_INFO = 0x4000;
	public static final int GAME_CODE_PLAYER_PLAYING_INFO = 0x4001;
	public static final int GAME_CODE_PLAYER_PLAYING_CARD = 0x4400;
	public static final int GAME_CODE_PLAYER_CHOOSE_PLAYER = 0x4401;
	public static final int GAME_CODE_ROUND_PHASE = 0x4402;
	public static final int GAME_CODE_PLAYER_GET_CARD = 0x4403;
	public static final int GAME_CODE_PLAYER_DISCARD_CARD = 0x4404;
	public static final int GAME_CODE_ROUND_SCORE = 0x4405;
}
