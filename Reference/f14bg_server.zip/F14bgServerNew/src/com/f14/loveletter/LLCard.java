/**
 * 
 */
package com.f14.loveletter;

import com.f14.bg.component.Card;

/**
 * @author 奈奈
 *
 */
public class LLCard extends Card implements Comparable<LLCard> {
	public double number;

	@Override
	public int compareTo(LLCard o) {
		if (this.number > o.number) {
			return 1;
		} else if (this.number < o.number) {
			return -1;
		} else {
			return 0;
		}
	}
}
