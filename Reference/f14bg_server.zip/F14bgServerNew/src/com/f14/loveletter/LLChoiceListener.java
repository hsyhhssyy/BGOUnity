package com.f14.loveletter;

import java.util.ArrayList;
import java.util.List;

import com.f14.bg.action.BgAction;
import com.f14.bg.action.BgResponse;
import com.f14.bg.exception.BoardGameException;
import com.f14.bg.listener.ActionListener;
import com.f14.bg.listener.ListenerType;
import com.f14.bg.player.Player;

public class LLChoiceListener extends ActionListener<LLGameMode> {
	protected LLPlayer trigPlayer;
	protected LLCard trigCard;

	public LLChoiceListener(LLPlayer player, LLCard card) {
		super(ListenerType.INTERRUPT);
		this.trigPlayer = player;
		this.trigCard = card;
		this.addListeningPlayer(trigPlayer);
	}

	@Override
	protected BgResponse createStartListenCommand(LLGameMode gameMode, Player player) {
		BgResponse res = super.createStartListenCommand(gameMode, player);
		res.setPublicParameter("msg", "请选择玩家");
		List<Integer> pos = new ArrayList<Integer>();
		for (LLPlayer p : gameMode.getGame().getValidPlayers()) {
			if (!p.passed && !p.protect) {
				if (p != this.trigPlayer || this.trigCard.number == 5)
					pos.add(p.position);
			}
		}
		res.setPublicParameter("targets", pos);
		return res;
	}

	@Override
	protected void setListenerInfo(BgResponse res) {
		super.setListenerInfo(res);
		// 设置触发玩家的位置参数
		res.setPublicParameter("trigPlayerPosition", this.trigPlayer.position);
	}

	@Override
	protected void doAction(LLGameMode gameMode, BgAction action) throws BoardGameException {
		if ("choice" == action.getAsString("subact")) {
			int pos = action.getAsInt("result");
			LLPlayer p = gameMode.getGame().getPlayer(pos);
			if (trigCard.number == 3) {
				if (this.trigPlayer.hand.getCards().get(0).number > p.hand.getCards().get(0).number) {
					p.passed = true;
					gameMode.game.playerPlayCard(p, p.hand.getCards().get(0));
				} else if (this.trigPlayer.hand.getCards().get(0).number < p.hand.getCards().get(0).number) {
					this.trigPlayer.passed = true;
					gameMode.game.playerPlayCard(this.trigPlayer, this.trigPlayer.hand.getCards().get(0));
				}
			}
		}
	}

	@Override
	protected int getValidCode() {
		// TODO Auto-generated method stub
		return LLGameCmd.GAME_CODE_PLAYER_CHOOSE_PLAYER;
	}

}
