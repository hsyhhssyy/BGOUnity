/**
 * 
 */
package com.f14.loveletter;

import com.f14.bg.BoardGameConfig;

/**
 * @author 奈奈
 *
 */
public class LLConfig extends BoardGameConfig {

}
