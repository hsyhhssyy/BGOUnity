package com.f14.innovation.exectuer;

import com.f14.bg.anim.AnimVar;
import com.f14.bg.exception.BoardGameException;
import com.f14.innovation.InnoGameMode;
import com.f14.innovation.InnoPlayer;
import com.f14.innovation.component.InnoCard;
import com.f14.innovation.component.ability.InnoAbility;
import com.f14.innovation.component.ability.InnoAbilityGroup;
import com.f14.innovation.consts.InnoAchieveTrigType;
import com.f14.innovation.consts.InnoAnimPosition;
import com.f14.innovation.param.InnoInitParam;
import com.f14.innovation.param.InnoResultParam;

/**
 * 按照指定的牌移除置顶牌的行动
 * 
 * @author F14eagle
 *
 */
public class InnoRemoveTopCardByCardExecuter extends InnoActionExecuter {

	public InnoRemoveTopCardByCardExecuter(InnoGameMode gameMode, InnoPlayer player, InnoInitParam initParam,
			InnoResultParam resultParam, InnoAbility ability, InnoAbilityGroup abilityGroup) {
		super(gameMode, player, initParam, resultParam, ability, abilityGroup);
	}

	@Override
	public void doAction() throws BoardGameException {
		InnoPlayer player = this.getTargetPlayer();
		for (InnoCard c : this.getResultCards()) {
			InnoCard card = player.removeTopCard(c.color);
			// 设置from参数
			AnimVar from = AnimVar.createAnimVar(InnoAnimPosition.PLAYER_STACKS, player.position, card.color);
			this.getResultParam().putAnimVar(card, from);
			// 刷新该牌堆的信息
			this.getGame().sendPlayerCardStackResponse(player, card.color, null);
			this.getGame().getReport().playerRemoveStackCard(player, card);

			gameMode.executeAchieveChecker(InnoAchieveTrigType.STACK_CHANGE, player);
		}
		this.getGame().sendPlayerIconsInfoResponse(player, null);
	}

}
