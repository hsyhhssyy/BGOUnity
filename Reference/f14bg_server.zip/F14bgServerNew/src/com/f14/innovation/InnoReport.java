package com.f14.innovation;

import com.f14.bg.report.BgReport;
import com.f14.innovation.component.InnoCard;
import com.f14.innovation.consts.InnoColor;
import com.f14.innovation.consts.InnoSplayDirection;

public class InnoReport extends BgReport {

	public InnoReport(Innovation bg) {
		super(bg);
	}

	public void playerAddHand(InnoPlayer player, int level) {
		this.action(player, "获得了手牌[" + level + "]");
	}

	public void playerAddScore(InnoPlayer player, int level) {
		this.action(player, "记分了[" + level + "]");

	}

	public void playerMeld(InnoPlayer player, InnoCard card) {
		this.action(player, "融合了" + card.getReportString());
	}

	public void playerRemoveHand(InnoPlayer player, int level) {
		this.action(player, "失去了手牌[" + level + "]");

	}

	public void playerRemoveScore(InnoPlayer player, int level) {
		this.action(player, "失去了分数[" + level + "]");

	}

	public void playerRemoveStackCard(InnoPlayer player, InnoCard c) {
		this.action(player, "失去了" + c.getReportString());

	}

	public void playerReturnCard(InnoPlayer player, int level) {
		this.action(player, "归还了[" + level + "]");

	}

	public void playerRevealHand(InnoPlayer player, InnoCard card) {
		this.action(player, "展示了手牌" + card.getReportString());

	}

	public void playerSplay(InnoPlayer player, InnoColor color, InnoSplayDirection splayDirection) {
		this.action(player,
				"将" + InnoColor.getDescr(color) + "牌堆向" + InnoSplayDirection.getDescr(splayDirection) + "展开");
	}

	public void playerTuck(InnoPlayer player, InnoCard card) {
		this.action(player, "垫底了" + card.getReportString());
	}

	public void playerDogmaCard(InnoPlayer player, InnoCard card) {
		this.action(player, "触发了" + card.getReportString());
	}

	public void playerDrawAchieveCard(InnoPlayer player, InnoCard card) {
		this.action(player, "获得了成就" + card.getReportString());
	}

	public void playerAddHand(InnoPlayer player, InnoCard card) {
		this.action(player, "获得了手牌" + card.getReportString());

	}

	public void playerAddScore(InnoPlayer player, InnoCard card) {
		this.action(player, "记分了" + card.getReportString());
	}

}
