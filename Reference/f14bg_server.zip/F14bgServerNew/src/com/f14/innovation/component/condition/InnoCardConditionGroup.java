package com.f14.innovation.component.condition;

import com.f14.bg.component.AbstractConditionGroup;
import com.f14.innovation.component.InnoCard;

public class InnoCardConditionGroup extends AbstractConditionGroup<InnoCard> {

}
