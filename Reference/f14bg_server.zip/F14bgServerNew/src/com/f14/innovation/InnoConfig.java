package com.f14.innovation;

import com.f14.bg.BoardGameConfig;

public class InnoConfig extends BoardGameConfig {
	public String mode;

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}
}
