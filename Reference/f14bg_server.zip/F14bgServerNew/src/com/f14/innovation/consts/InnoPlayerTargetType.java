package com.f14.innovation.consts;

/**
 * Innovation目标玩家类型
 * 
 * @author F14eagle
 *
 */
public enum InnoPlayerTargetType {
	MAIN_PLAYER, TRIG_PLAYER, CURRENT_PLAYER,
}
