package com.f14.innovation.consts;

/**
 * 动画的位置
 * 
 * @author F14eagle
 *
 */
public enum InnoAnimPosition {
	PLAYER_HANDS, PLAYER_SCORES, PLAYER_STACKS, PLAYER_ACHIEVES, DRAW_DECK, ACHIEVE_DECK, SPECIAL_ACHIEVE_DECK,
}
