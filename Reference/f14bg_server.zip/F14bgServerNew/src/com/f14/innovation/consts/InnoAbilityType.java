package com.f14.innovation.consts;

public enum InnoAbilityType {
	EXECUTER, LISTENER, CHECKER,
}
