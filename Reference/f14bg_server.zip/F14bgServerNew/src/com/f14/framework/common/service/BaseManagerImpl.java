package com.f14.framework.common.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.f14.framework.common.dao.BaseDao;
import com.f14.framework.common.model.BaseModel;
import com.f14.framework.common.model.PageModel;

/**
 * 
 * @author F14eagle
 *
 * @param <T>
 * @param <PK>
 */
public class BaseManagerImpl<T extends BaseModel, PK extends java.io.Serializable> implements BaseManager<T, PK> {
	protected final Logger log = Logger.getLogger(getClass());

	protected BaseDao<T, PK> dao;

	protected void setDao(BaseDao<T, PK> dao) {
		this.dao = dao;
	}

	@Override
	public void delete(PK id) {
		this.dao.delete(id);
	}

	@Override
	public void delete(T model) {
		this.dao.delete(model);
	}

	@Override
	public boolean exists(PK id) {
		return this.dao.exists(id);
	}

	@Override
	public T get(PK id) {
		return this.dao.get(id);
	}

	@Override
	public List<T> getAll() {
		return this.dao.getAll();
	}

	@Override
	public List<T> query(T condition) {
		return this.dao.query(condition);
	}

	@Override
	public PageModel<T> query(PageModel<T> pm) {
		return this.dao.query(pm);
	}

	@Override
	public PageModel<T> queryByCriteria(PageModel<T> pm) {
		return this.dao.queryByCriteria(pm);
	}

	@Override
	public T save(T model) {
		return this.dao.save(model);
	}

	@Override
	public T update(T model) {
		return this.dao.update(model);
	}

	@Override
	public int count(T condition) {
		return this.dao.count(condition);
	}

	@Override
	public List<T> query(T condition, String order) {
		return this.dao.query(condition, order);
	}

	@Override
	public PageModel<T> query(PageModel<T> pm, String order) {
		return this.dao.query(pm, order);
	}

	@Override
	public PageModel<T> queryByCriteria(PageModel<T> pm, String order) {
		return this.dao.queryByCriteria(pm, order);
	}

	@Override
	public List<T> queryByCriteria(T condition) {
		return this.dao.queryByCriteria(condition);
	}

	@Override
	public List<T> queryByCriteria(T condition, String order) {
		return this.dao.queryByCriteria(condition, order);
	}

}
