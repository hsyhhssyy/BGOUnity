package com.f14.framework.common.model;

public class UserInfo {

}
