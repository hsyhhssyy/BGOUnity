package com.f14.f14bgdb.service;

import com.f14.f14bgdb.model.CodeDetail;
import com.f14.framework.common.service.BaseManager;

public interface CodeDetailManager extends BaseManager<CodeDetail, Long> {

}
