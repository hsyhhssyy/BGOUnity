package com.f14.f14bgdb.dao;

import com.f14.f14bgdb.model.BgInstance;
import com.f14.framework.common.dao.BaseDao;

public interface BgInstanceDao extends BaseDao<BgInstance, Long> {

}
