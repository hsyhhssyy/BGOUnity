package com.f14.f14bgdb.dao;

import com.f14.f14bgdb.model.User;
import com.f14.framework.common.dao.BaseDao;

public interface UserDao extends BaseDao<User, Long> {

}
