package com.f14.f14bgdb.dao;

import com.f14.f14bgdb.model.CodeDetail;
import com.f14.framework.common.dao.BaseDao;

public interface CodeDetailDao extends BaseDao<CodeDetail, Long> {

}
