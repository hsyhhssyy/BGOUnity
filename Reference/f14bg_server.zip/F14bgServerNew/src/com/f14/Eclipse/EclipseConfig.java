package com.f14.Eclipse;

import com.f14.bg.BoardGameConfig;

public class EclipseConfig extends BoardGameConfig {

}
