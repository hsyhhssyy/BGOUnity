package com.f14.Eclipse;

import com.f14.bg.report.BgReport;

public class EclipseReport extends BgReport {

	public EclipseReport(Eclipse bg) {
		super(bg);
	}

}
