package com.f14.Eclipse.consts;

public enum EclipseAnimObject {
	CUBE, UNIT, PLANET, DISC, TECHNOLOGY, SHIP_PART,
}
