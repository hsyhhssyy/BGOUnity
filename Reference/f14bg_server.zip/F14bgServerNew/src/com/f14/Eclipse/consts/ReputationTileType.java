package com.f14.Eclipse.consts;

public enum ReputationTileType {
	AMBASSADOR, REPUTATION,
}
