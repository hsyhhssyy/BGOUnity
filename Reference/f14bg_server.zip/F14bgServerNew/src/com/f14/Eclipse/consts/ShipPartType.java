package com.f14.Eclipse.consts;

public enum ShipPartType {
	WEAPON, COMPUTER, SHIELD, HULL, DRIVE, ENERGY_SOURCE,
}
