package com.f14.Eclipse.consts;

/**
 * 飞船配件类别
 *
 * @author f14eagle
 */
public enum ShipPartCategory {
	BASE, TECHNOLOGY, DISCOVERY, EMPTY,
}
