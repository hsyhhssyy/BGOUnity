package com.f14.Eclipse.consts;

public enum ReputationSquareType {
	SINGLE, MULTIPLE,
}
