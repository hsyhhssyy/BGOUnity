package com.f14.Eclipse.consts;

/**
 * 蓝图类型
 *
 * @author f14eagle
 */
public enum BlueprintType {
	SHIP, STRUCTURE,
}
