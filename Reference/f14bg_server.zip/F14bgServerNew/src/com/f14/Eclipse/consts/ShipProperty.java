package com.f14.Eclipse.consts;

/**
 * 飞船的属性
 *
 * @author f14eagle
 */
public enum ShipProperty {
	DAMAGE, TO_HIT, DODGE, HP, INITIATIVE, MOVEMENT, ENERGY, ENERGY_COST,
}
