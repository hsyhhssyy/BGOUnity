package com.f14.Eclipse.consts;

/**
 * 武器类型
 *
 * @author f14eagle
 */
public enum WeaponType {
	CANNON, MISSILE,
}
