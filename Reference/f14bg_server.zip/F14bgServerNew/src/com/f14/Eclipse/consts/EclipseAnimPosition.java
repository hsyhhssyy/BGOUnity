package com.f14.Eclipse.consts;

public enum EclipseAnimPosition {
	PLAYER_BOARD, HEX, PUBLIC_BOARD,
}
