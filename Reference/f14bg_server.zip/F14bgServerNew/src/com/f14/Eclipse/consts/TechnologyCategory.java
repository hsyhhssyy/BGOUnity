package com.f14.Eclipse.consts;

public enum TechnologyCategory {
	MILITARY, GRID, NANO,
}
