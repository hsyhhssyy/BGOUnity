package com.f14.Eclipse.consts;

public enum ActionType {
	EXPLORE, INFLUENCE, RESEARCH, UPGRADE, BUILD, MOVE, TRADE, COLONIZE,
}
