package com.f14.Eclipse.consts;

/**
 * Direction for hex
 *
 * @author f14eagle
 */
public class Direction {
	public static int DIRECTION_0 = 0;
	public static int DIRECTION_1 = 1;
	public static int DIRECTION_2 = 2;
	public static int DIRECTION_3 = 3;
	public static int DIRECTION_4 = 4;
	public static int DIRECTION_5 = 5;
}
