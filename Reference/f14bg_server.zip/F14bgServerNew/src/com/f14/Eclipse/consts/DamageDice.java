package com.f14.Eclipse.consts;

/**
 * 伤害骰
 *
 * @author f14eagle
 */
public enum DamageDice {
	ION, PLASMA, ANTIMATTER,
}
