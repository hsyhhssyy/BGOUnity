package com.f14.Eclipse.component;

import com.f14.bg.component.CardDeck;

public class TechnologyDeck extends CardDeck<Technology> {

}
