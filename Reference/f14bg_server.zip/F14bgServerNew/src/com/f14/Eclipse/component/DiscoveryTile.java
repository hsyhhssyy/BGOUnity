package com.f14.Eclipse.component;

import com.f14.bg.component.Card;

public class DiscoveryTile extends Card {

}
