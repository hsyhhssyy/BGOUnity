package com.f14.F14bgClient.update;

/**
 * 默认的更新监听器
 * 
 * @author F14eagle
 *
 */
public class DefaultUpdaterListener implements IUpdaterListener {

	@Override
	public void onUpdateFailure() {

	}

	@Override
	public void onUpdateSuccess(boolean updated) {

	}

}
