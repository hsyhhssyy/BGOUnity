package com.f14.F14bgClient.event;

public class FlashShellEvent extends F14bgEvent {

}
