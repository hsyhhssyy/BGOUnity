package com.f14.F14bgClient.FlashHandler;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import cn.smartinvoke.IServerObject;

import com.f14.F14bgClient.manager.ManagerContainer;

/**
 * 处理大厅界面指令的接收器
 * 
 * @author F14eagle
 *
 */
public class RoomHandler implements IServerObject {

	/**
	 * 用户退出房间的请求
	 */
	public void leaveRequest(int roomId) {
		ManagerContainer.actionManager.leaveRequest(roomId);
	}

	public void saveReport(final String report) {
		Date now = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		String fileName = format.format(now).concat(".txt");
		try {
			FileOutputStream stream = new FileOutputStream(new File(fileName));
			stream.write(report.getBytes());
			stream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void dispose() {

	}

}
