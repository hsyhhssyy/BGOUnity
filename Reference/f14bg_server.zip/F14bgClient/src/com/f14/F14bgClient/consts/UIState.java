package com.f14.F14bgClient.consts;

/**
 * 界面状态
 * 
 * @author F14eagle
 *
 */
public enum UIState {
	/**
	 * 登录界面
	 */
	LOGIN, /**
			 * 大厅界面
			 */
	HALL,
}
