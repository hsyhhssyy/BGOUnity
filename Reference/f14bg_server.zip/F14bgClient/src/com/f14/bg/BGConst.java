package com.f14.bg;

public class BGConst {
	/**
	 * 表示null的int值
	 */
	public static final int INT_NULL = Integer.MIN_VALUE;
}
