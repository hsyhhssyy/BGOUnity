package com.f14.bg.chat;

public interface Chatable {

	/**
	 * 发送消息
	 * 
	 * @param msg
	 */
	public void sendMessage(String msg);
}
